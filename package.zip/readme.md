Order Producer Lambda

This AWS Lambda function, written in TypeScript, processes incoming order data, validates it, transforms it to a target format, and publishes it to a webhook.site endpoint.

Features





Validates incoming source order data



Transforms data to target model format



Publishes transformed data to webhook.site



Provides health check endpoint



Comprehensive error handling and logging

Project Structure

project-root/
├── src/
│   ├── index.ts          // Main Lambda handler
│   ├── validator.ts      // Validation logic
│   ├── transformer.ts    // Transformation logic
│   ├── publisher.ts      // Webhook publishing logic
│   ├── logger.ts         // Logger configuration
│   └── types.ts          // TypeScript interfaces
├── README.md             // Documentation
├── package.json          // Dependencies
├── tsconfig.json         // TypeScript configuration
└── tests/                // Unit tests

Setup Instructions





Install Dependencies:

npm install



Configure Webhook.site:





Create a new webhook endpoint at https://webhook.site



Note the unique URL provided



Store the URL in AWS Parameter Store under /order/producer/webhook-url



Environment Variables:





Set WEBHOOK_URL_PARAM to the Parameter Store path if different from default



Compile TypeScript:

npm run build



Deploy Lambda:





Create a new Lambda function named [service]-[entity]-producer



Configure API Gateway with endpoints:





POST /[service]/[entity]-producer/v1



GET /[service]/[entity]-producer/v1/healthCheck



Set appropriate IAM permissions for Parameter Store access



Deploy the compiled JavaScript files from the dist folder

API Contract

POST /[service]/[entity]-producer/v1

Request Body:

interface SourceOrderData {
  orderId: string; // Required: Order identifier
  orderDate: string; // Required: MM/DD/YYYY
  customerId: string; // Required
  storeId: number; // Required
  items: Array<{
    sku: string;
    quantity: number;
    unitPrice: number;
    discountAmount?: number;
  }>;
  paymentMethod: string; // Required
  shippingAddress?: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  totalAmount: number; // Required
  status: string; // Required: NEW, PROCESSING, SHIPPED, DELIVERED, CANCELLED
  notes?: string;
}

Response:





200: { status: true, orderId: string }



400: { errors: string[] }



500: { message: string }

GET /[service]/[entity]-producer/v1/healthCheck

Response:





200: { status: 'healthy' }

Error Handling





Validation errors return 400 with detailed error messages



Webhook publication failures return 500



Unexpected errors are logged and return 500



Sensitive information is masked in logs

Troubleshooting





Check CloudWatch logs for detailed error messages



Verify webhook.site URL in Parameter Store



Ensure Lambda has proper IAM permissions



Validate input data format against SourceOrderData interface

Testing





Unit tests achieve ≥ 80% coverage



Test cases cover:





Valid data processing



Invalid data validation



Error scenarios



Health check endpoint